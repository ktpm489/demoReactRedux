import React, {Component } from 'react'
import ProfilePage from './view'
export default class Profile extends Component {
  render () {
    return (
      <ProfilePage/>
    )
  }
}
