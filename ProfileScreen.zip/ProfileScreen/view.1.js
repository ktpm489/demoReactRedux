import React from 'react'
import { width, heightScale, height } from 'common/globalStyles'
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native'
import CoreLayout from 'frontend/Container/CoreLayoutContainer'
import QRCode from 'react-native-qrcode'
const profileDefault = require('assets/Image/Profile/profile.png')
const profilePage = (props) => {
  return (
    <CoreLayout title={'Profile'}>
      <View style={styles.backgroundDefault}>
        <View style={styles.viewImageContainer}>

          {/* <TouchableOpacity style={styles.imgIconContainer}>
            <View style={styles.iconTitle}>
              <Image source={profileDefault} style={styles.imgIcon}/>
            </View>
          </TouchableOpacity> */}
          <View style={styles.container}>
            <View style={styles.outerCircle}>
              {/* <View style={styles.innerCircle} /> */}
              <Image source={profileDefault} style={styles.innerCircle} />
            </View>
          </View>

          <View style={styles.descriptionContainer}>
            <Text style={styles.textName}>{'Default name 123'}</Text>
            <Text style={styles.etherAddress}>{'Ether address'}</Text>
            <Text style={styles.etherAddressDetail}>{'0xd6224be81ef9bc47d8ac03910bf46c6nd9204kf1'}</Text>
            <View>
            </View>
          </View>
          <View style={styles.whiteLineDetail} />
          <View style={styles.linkProfileContainer}>
            <Text style={styles.linkProfile}>{'Link to profile'}</Text>
            <TouchableOpacity>
              <Text style={styles.linkProfileDescription}> {'http://hb_wallet0xkfieiks'} </Text>
            </TouchableOpacity>
          </View>
          <View style={styles.qrLinkCodeContainer}>
            <TouchableOpacity>
              <QRCode
                value={'http://hb_wallet0xkfieiks'}
                size={width(40)}
                bgColor='white'
                fgColor='black'
              />
              <Text style={styles.tapText}>{'Tap to copy'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </CoreLayout>

  )
}
const styles = StyleSheet.create({
  backgroundDefault: {
    flex: 1
  },
  viewImageContainer: {
    // flex: 1,
    width: width(100),
    alignItems: 'center',
    justifyContent: 'center'
    // paddingHorizontal: heightScale(6)
  },
  iconTitle: {
    overflow: 'hidden',
    // height: heightScale(30),
    width: width(100),
    alignItems: 'center',
    // backgroundColor: 'red',
    justifyContent: 'flex-start',
    paddingTop: height(2)
  },
  imgIconContainer: {
    width: width(35),
    height: width(35),
    borderRadius: width(35) / 2,
    borderColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    // backgroundColor: '#99a4ab',
    borderWidth: width(0.5)
  },
  imgIcon: {
    width: width(30),
    height: width(28),
    borderRadius: width(5),
    backgroundColor: 'red',
    overflow: 'hidden'
    // borderRadius: width(4),
    // borderColor: 'white'
  },
  descriptionContainer: {
    paddingTop: heightScale(2),
    justifyContent: 'flex-start',
    alignItems: 'center'
  },
  textName: {
    color: 'white',
    fontSize: width(5),
    paddingBottom: heightScale(2)
  },
  etherAddress: {
    color: '#99a4ab',
    fontSize: width(4.5)
  },
  etherAddressDetail: {
    color: '#99a4ab',
    paddingTop: heightScale(1),
    paddingBottom: heightScale(8),
    fontSize: width(3.8)
  },
  whiteLineDetail: {
    width: width(92),
    alignSelf: 'center',
    backgroundColor: 'white',
    opacity: 0.2,
    height: heightScale(0.15)
  },
  linkProfileContainer: {
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingTop: heightScale(2),
    paddingBottom: heightScale(1)
  },
  linkProfile: {
    color: '#99a4ab',
    fontSize: width(4)
  },
  linkProfileDescription: {
    color: 'white',
    fontSize: width(4.5),
    textDecorationLine: 'underline',
    paddingTop: heightScale(1)
  },
  qrLinkCodeContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: height(2)
  },
  tapText: {
    paddingTop: height(2),
    color: 'white',
    textAlign: 'center',
    fontSize: width(4.5)
  },
  container: {
    width: width(100),
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden'
    // paddingHorizontal: height(2)
    // backgroundColor: 'red'
  },
  outerCircle: {
    borderRadius: 145 / 2,
    width: 145,
    height: 145,
    backgroundColor: '#46586B',
    overflow: 'hidden',
    borderWidth: width(0.5),
    borderColor: 'white'
  },
  innerCircle: {
    borderRadius: 90 / 2,
    width: 120,
    height: 150,
    position: 'relative',
    marginTop: 18,
    overflow: 'hidden',
    alignSelf: 'center',
    backgroundColor: 'transparent'
  }
})

export default profilePage
